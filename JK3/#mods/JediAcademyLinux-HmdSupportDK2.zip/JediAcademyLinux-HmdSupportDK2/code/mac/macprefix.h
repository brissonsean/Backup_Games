//#define __MACOS__		// needed for MrC
#define	BOTLIB

