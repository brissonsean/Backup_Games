#include "../game/q_shared.h"

#ifdef __APPLE__
void	QDECL Com_Error( int level, const char *error, ... )
{
    
}

void	QDECL Com_Printf( const char *msg, ... )
{
    
}
#endif
