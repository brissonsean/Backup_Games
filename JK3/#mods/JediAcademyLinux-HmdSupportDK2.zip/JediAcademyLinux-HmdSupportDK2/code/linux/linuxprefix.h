#define	BOTLIB

