// PCH header file organiser for  NPC_xxxx cpp files' most commonly used headers

#include "b_local.h"
#include "anims.h"
#include "g_functions.h"
#include "g_nav.h"
#include "g_navigator.h"
